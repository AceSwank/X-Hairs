<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Cheetah Facts Form</title>

    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="style2.css" />

    <script src="news_letter.js"></script>

    <title>Cheetah Forms</title>

    <div class="header" style="background-image: url('images/leopard-4537098_1920.jpg');">
      <h1>Cheetah Facts Form</h1>
      <p>A fun site all about neat cheetah facts.</p>
      <p id="mail"> Please sign up to our newsletter!</p>
    </div>

    <div class="navbar">
      <a href="XSS_Site.html" class="active">Home</a>
      <a href="chat.php">Chat Forms</a>
      <a id="Newsletter" onclick="writeCookie();">Newsletter</a>
      <a href="lookup.html" class="right">Help</a>
    </div>

  </head>
  <body onload="checkCookie();">
    <section>
      <form action="chat.php" method="GET" autocomplete="off"> 
        <div class="form-control">
          <label for="user-message">Your Message</label>
          <input type="text" name="user-message" min="2" max=150>
        </div>
        <input type="submit">
      </form>
    </section>

    <section id="user-messages">
      <form action="chat.php" method="post">
      <div>
            <p>
              <?php 
                $spice = fopen("testing.txt","a+") or die("No access to the file!");
                $sauce = $_GET["user-message"];
                fwrite($spice, $sauce."\n");
                fclose($spice);
                $sugar = htmlentities(file_get_contents("testing.txt"), ENT_QUOTES, 'UTF-8');
                echo nl2br($sugar);
                ?>
            </p>
        </div>
      </form>
      <ul></ul>
    </section>
  </body>
</html>